
// Navbar Scroll Effect
window.addEventListener('scroll', () => {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Smooth Scrolling for internal links is handled by CSS (scroll-behavior: smooth)
// This script block is ready for additional dynamic functionality like carousels or cart logic.
